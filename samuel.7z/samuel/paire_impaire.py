from time import sleep
import _thread
import utime
from lcd1602A import *

lcd_init()
lcd_string("Select Histoire!",LCD_LINE_1)
lcd_string("00:00",LCD_LINE_2)

