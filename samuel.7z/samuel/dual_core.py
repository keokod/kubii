from machine import Pin
import utime
import _thread

# declaring led object
led_0 = Pin(14, Pin.IN, Pin.PULL_UP) #bouton orange GROOVE1
led_1 = Pin(15, Pin.IN, Pin.PULL_UP) #bouton orange GROOVE1

spLock = _thread.allocate_lock()  # creating semaphore lock

def core1_task():
    while True:
        spLock.acquire()  # acquiring semaphore lock
        print(" message from core_1")
        led_1.value(1)
        utime.sleep(0.5)  # 0.5 sec or 500us delay
        led_1.value(0)
        spLock.release()

    _thread.start_new_thread(core1_task, ())

while True:
    spLock.acquire()
    print("message from Core_0")
    print("...")
    led_0.value(1)
    utime.sleep(0.5)
    led_0.value(0)
    spLock.release()
    utime.sleep(5)
    print("message from Core_1...")
    core1_task()
    spLock.release()

