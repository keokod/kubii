 
#import
from machine import Pin
import utime
 
# Define GPIO to LCD mapping
LCD_RS = 12
LCD_E  = 11
LCD_D4 = 22 #jaune
LCD_D5 = 21 #vert
LCD_D6 = 16 #bleu
LCD_D7 = 17 #violet
 
# Define some device constants
LCD_WIDTH = 16    # Maximum characters per line
LCD_CHR = 1
LCD_CMD = 0
 
LCD_LINE_1 = 0x80 # LCD RAM address for the 1st line
LCD_LINE_2 = 0xC0 # LCD RAM address for the 2nd line
 
# Timing constants
E_PULSE = 0.0005
E_DELAY = 0.0005
 
def lcd_init():
  # Initialise display
  lcd_byte(0x33,LCD_CMD) # 110011 Initialise
  lcd_byte(0x32,LCD_CMD) # 110010 Initialise
  lcd_byte(0x06,LCD_CMD) # 000110 Cursor move direction
  lcd_byte(0x0C,LCD_CMD) # 001100 Display On,Cursor Off, Blink Off
  lcd_byte(0x28,LCD_CMD) # 101000 Data length, number of lines, font size
  lcd_byte(0x01,LCD_CMD) # 000001 Clear display
  utime.sleep(E_DELAY)
 
def lcd_byte(bits, mode):
  # Send byte to data pins
  # bits = data
  # mode = True  for character
  #        False for command
  PinRS = Pin(LCD_RS, Pin.OUT)
  PinRS.value(mode)
  #Pin(LCD_RS, mode) # RS
  PinD4 = Pin(LCD_D4, Pin.OUT)#jaune
  PinD5 = Pin(LCD_D5, Pin.OUT)#vert
  PinD6 = Pin(LCD_D6, Pin.OUT)#bleu
  PinD7 = Pin(LCD_D7, Pin.OUT)#violet
  
  # High bits
  #Pin(LCD_D4, False)
  PinD4.value(0)
  #Pin(LCD_D5, False)
  PinD5.value(0)
  #Pin(LCD_D6, False)
  PinD6.value(0)
  #Pin(LCD_D7, False)
  PinD7.value(0)
  if bits&0x10==0x10:
    #Pin(LCD_D4, True)
    PinD4.value(1)
  if bits&0x20==0x20:
    #Pin(LCD_D5, True)
    PinD5.value(1)
  if bits&0x40==0x40:
    #Pin(LCD_D6, True)
    PinD6.value(1)
  if bits&0x80==0x80:
    #Pin(LCD_D7, True)
    PinD7.value(1)
 
  # Toggle 'Enable' pin
  lcd_toggle_enable()
 
  # Low bits
  #Pin(LCD_D4, False)
  PinD4.value(0)
  #Pin(LCD_D5, False)
  PinD5.value(0)
  #Pin(LCD_D6, False)
  PinD6.value(0)
  #Pin(LCD_D7, False)
  PinD7.value(0)
  if bits&0x01==0x01:
    #Pin(LCD_D4, True)
    PinD4.value(1)
  if bits&0x02==0x02:
    #Pin(LCD_D5, True)
    PinD5.value(1)
  if bits&0x04==0x04:
    #Pin(LCD_D6, True)
    PinD6.value(1)
  if bits&0x08==0x08:
    #Pin(LCD_D7, True)
    PinD7.value(1)
 
  # Toggle 'Enable' pin
  lcd_toggle_enable()
 
def lcd_toggle_enable():
  # Toggle enable
  PinE = Pin(LCD_E, Pin.OUT)
  utime.sleep(E_DELAY)
  #Pin(LCD_E, True)
  PinE.value(1)
  utime.sleep(E_PULSE)
  #Pin(LCD_E, False)
  PinE.value(0)
  utime.sleep(E_DELAY)
 
def lcd_string(message,line):
  # Send string to display
 
  MESSAGE_SPACE = LCD_WIDTH-len(message)
  i=0
  print(message)
  while i<MESSAGE_SPACE:
      message = message + " "
      i+=1 
  lcd_byte(line, LCD_CMD)
  for i in range(LCD_WIDTH):
    lcd_byte(ord(message[i]),LCD_CHR)
    


 

 

