from machine import Pin
import time
#configurer adressse A0_A3 en sortie pull_up
A0 = Pin(14, Pin.OUT, Pin.PULL_UP) #bouton vert
A1 = Pin(15, Pin.OUT, Pin.PULL_UP) #bouton vert
A2 = Pin(19, Pin.OUT, Pin.PULL_UP) #bouton vert
A3 = Pin(20, Pin.OUT, Pin.PULL_UP) #bouton vert

button_stable = Pin(0, Pin.IN, Pin.PULL_UP) #bouton vert
button_bistable = Pin(1, Pin.IN, Pin.PULL_UP) #bouton vert

while True:
    if button_stable.value()==0:
      print("reset")
      time.sleep(1)
    if button_bistable.value()==0:
      print("history")
      time.sleep(1)
    else:
      print("no select history")
      time.sleep(1)
