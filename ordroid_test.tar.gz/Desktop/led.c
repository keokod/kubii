#include <wiringPi.h>
 
int main(void)
{
    wiringPiSetup();
    pinMode(8, OUTPUT);
    pinMode(9, OUTPUT);
    pinMode(7, OUTPUT);
 
    pinMode(0, OUTPUT);
    pinMode(2, OUTPUT);
    pinMode(3, OUTPUT);
    
    pinMode(12, OUTPUT);
    pinMode(13, OUTPUT);
    pinMode(14, OUTPUT);
    
    pinMode(30, OUTPUT);
    pinMode(21, OUTPUT);
    pinMode(22, OUTPUT);
    pinMode(23, OUTPUT);
    pinMode(24, OUTPUT);
    
    pinMode(15, OUTPUT);
    pinMode(16, OUTPUT);
    pinMode(1, OUTPUT);
    
    pinMode(4, OUTPUT);
    pinMode(5, OUTPUT);
    
    pinMode(6, OUTPUT);
    pinMode(10, OUTPUT);
    pinMode(11, OUTPUT);
    pinMode(31, OUTPUT);
    
    pinMode(26, OUTPUT);
    pinMode(27, OUTPUT);
    
    
    
    
    for (;;)
    {
        digitalWrite(8, HIGH); 
        delay(120);
        digitalWrite(8, LOW); 
        delay(50);
        digitalWrite(9, HIGH); 
        delay(120);
        digitalWrite(9, LOW); 
        delay(50);
        digitalWrite(7, HIGH); 
        delay(120);
        digitalWrite(7, LOW); 
        delay(50);
        
        digitalWrite(0, HIGH); 
        delay(120);
        digitalWrite(0, LOW); 
        delay(50);
        digitalWrite(2, HIGH); 
        delay(120);
        digitalWrite(2, LOW); 
        delay(50);
        digitalWrite(3, HIGH); 
        delay(120);
        digitalWrite(3, LOW); 
        delay(50);
        
        digitalWrite(12, HIGH); 
        delay(120);
        digitalWrite(12, LOW); 
        delay(50);
        digitalWrite(13, HIGH); 
        delay(120);
        digitalWrite(13, LOW); 
        delay(50);
        digitalWrite(14, HIGH); 
        delay(120);
        digitalWrite(14, LOW); 
        delay(50);
        
        digitalWrite(30, HIGH); 
        delay(120);
        digitalWrite(30, LOW); 
        delay(50);
        digitalWrite(21, HIGH); 
        delay(120);
        digitalWrite(21, LOW); 
        delay(50);
        digitalWrite(22, HIGH); 
        delay(120);
        digitalWrite(22, LOW); 
        delay(50);
        digitalWrite(23, HIGH); 
        delay(120);
        digitalWrite(23, LOW); 
        delay(50);
        digitalWrite(24, HIGH); 
        delay(120);
        digitalWrite(24, LOW); 
        delay(50);       
        
        digitalWrite(15, HIGH); 
        delay(120);
        digitalWrite(15, LOW); 
        delay(50);
        digitalWrite(16, HIGH); 
        delay(120);
        digitalWrite(16, LOW); 
        delay(50);
        digitalWrite(1, HIGH); 
        delay(120);
        digitalWrite(1, LOW); 
        delay(50);
        
        digitalWrite(4, HIGH); 
        delay(120);
        digitalWrite(4, LOW); 
        delay(50);
        digitalWrite(5, HIGH); 
        delay(120);
        digitalWrite(5, LOW); 
        delay(50);
        
        digitalWrite(6, HIGH); 
        delay(120);
        digitalWrite(6, LOW); 
        delay(50);
        digitalWrite(10, HIGH); 
        delay(120);
        digitalWrite(10, LOW); 
        delay(50);
         digitalWrite(11, HIGH); 
        delay(120);
        digitalWrite(11, LOW);  
        delay(50);
        digitalWrite(31, HIGH); 
        delay(120);
        digitalWrite(31, LOW); 
        delay(50);
        
        digitalWrite(26, HIGH); 
        delay(120);
        digitalWrite(26, LOW); 
        delay(50);
        
        digitalWrite(27, HIGH); 
        delay(120);
        digitalWrite(27, LOW); 
        delay(50);
        
        
    }
    return 0;
}
